#!/usr/bin/env python3

import liveodds


def main():

    meetings = liveodds.list_courses()

    for meet in meetings:
        for race in liveodds.list_races(meet):
            print(race)



if __name__ == '__main__':
    main()
